<?php
// created: 2024-03-06 15:29:55
$dictionary["ad123_Students"]["fields"]["ad123_students_ad123_teachers"] = array (
  'name' => 'ad123_students_ad123_teachers',
  'type' => 'link',
  'relationship' => 'ad123_students_ad123_teachers',
  'source' => 'non-db',
  'module' => 'ad123_Teachers',
  'bean_name' => 'ad123_Teachers',
  'vname' => 'LBL_AD123_STUDENTS_AD123_TEACHERS_FROM_AD123_TEACHERS_TITLE',
);
