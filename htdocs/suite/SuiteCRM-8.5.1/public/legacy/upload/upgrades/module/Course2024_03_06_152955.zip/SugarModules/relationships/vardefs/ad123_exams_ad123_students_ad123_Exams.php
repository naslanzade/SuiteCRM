<?php
// created: 2024-03-05 13:06:25
$dictionary["ad123_Exams"]["fields"]["ad123_exams_ad123_students"] = array (
  'name' => 'ad123_exams_ad123_students',
  'type' => 'link',
  'relationship' => 'ad123_exams_ad123_students',
  'source' => 'non-db',
  'module' => 'ad123_Students',
  'bean_name' => 'ad123_Students',
  'vname' => 'LBL_AD123_EXAMS_AD123_STUDENTS_FROM_AD123_STUDENTS_TITLE',
);
