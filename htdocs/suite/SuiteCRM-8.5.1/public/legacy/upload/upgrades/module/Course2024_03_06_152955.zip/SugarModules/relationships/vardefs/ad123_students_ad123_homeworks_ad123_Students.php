<?php
// created: 2024-03-06 15:29:55
$dictionary["ad123_Students"]["fields"]["ad123_students_ad123_homeworks"] = array (
  'name' => 'ad123_students_ad123_homeworks',
  'type' => 'link',
  'relationship' => 'ad123_students_ad123_homeworks',
  'source' => 'non-db',
  'module' => 'ad123_Homeworks',
  'bean_name' => 'ad123_Homeworks',
  'vname' => 'LBL_AD123_STUDENTS_AD123_HOMEWORKS_FROM_AD123_HOMEWORKS_TITLE',
);
