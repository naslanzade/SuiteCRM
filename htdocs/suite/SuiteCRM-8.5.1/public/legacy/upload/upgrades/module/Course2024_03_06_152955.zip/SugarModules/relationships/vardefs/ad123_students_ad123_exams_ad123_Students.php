<?php
// created: 2024-03-06 15:29:55
$dictionary["ad123_Students"]["fields"]["ad123_students_ad123_exams"] = array (
  'name' => 'ad123_students_ad123_exams',
  'type' => 'link',
  'relationship' => 'ad123_students_ad123_exams',
  'source' => 'non-db',
  'module' => 'ad123_Exams',
  'bean_name' => 'ad123_Exams',
  'vname' => 'LBL_AD123_STUDENTS_AD123_EXAMS_FROM_AD123_EXAMS_TITLE',
);
