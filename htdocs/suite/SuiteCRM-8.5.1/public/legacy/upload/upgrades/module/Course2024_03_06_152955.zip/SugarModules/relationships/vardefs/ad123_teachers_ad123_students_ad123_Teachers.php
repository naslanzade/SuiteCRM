<?php
// created: 2024-03-06 15:29:55
$dictionary["ad123_Teachers"]["fields"]["ad123_teachers_ad123_students"] = array (
  'name' => 'ad123_teachers_ad123_students',
  'type' => 'link',
  'relationship' => 'ad123_teachers_ad123_students',
  'source' => 'non-db',
  'module' => 'ad123_Students',
  'bean_name' => 'ad123_Students',
  'vname' => 'LBL_AD123_TEACHERS_AD123_STUDENTS_FROM_AD123_STUDENTS_TITLE',
);
