<?php
// created: 2024-03-06 15:23:56
$dictionary["ad123_Homeworks"]["fields"]["ad123_homeworks_ad123_students"] = array (
  'name' => 'ad123_homeworks_ad123_students',
  'type' => 'link',
  'relationship' => 'ad123_homeworks_ad123_students',
  'source' => 'non-db',
  'module' => 'ad123_Students',
  'bean_name' => 'ad123_Students',
  'vname' => 'LBL_AD123_HOMEWORKS_AD123_STUDENTS_FROM_AD123_STUDENTS_TITLE',
);
