<?php
// created: 2024-03-05 13:06:26
$dictionary["ad123_Teachers"]["fields"]["ad123_exams_ad123_teachers"] = array (
  'name' => 'ad123_exams_ad123_teachers',
  'type' => 'link',
  'relationship' => 'ad123_exams_ad123_teachers',
  'source' => 'non-db',
  'module' => 'ad123_Exams',
  'bean_name' => 'ad123_Exams',
  'side' => 'right',
  'vname' => 'LBL_AD123_EXAMS_AD123_TEACHERS_FROM_AD123_EXAMS_TITLE',
);
