<?php
// created: 2024-03-06 15:23:56
$dictionary["ad123_Teachers"]["fields"]["ad123_homeworks_ad123_teachers"] = array (
  'name' => 'ad123_homeworks_ad123_teachers',
  'type' => 'link',
  'relationship' => 'ad123_homeworks_ad123_teachers',
  'source' => 'non-db',
  'module' => 'ad123_Homeworks',
  'bean_name' => 'ad123_Homeworks',
  'side' => 'right',
  'vname' => 'LBL_AD123_HOMEWORKS_AD123_TEACHERS_FROM_AD123_HOMEWORKS_TITLE',
);
